//
//  CollectionPlacesViewController.h
//  Lab6
//
//  Created by Daler Asrorov on 11/20/16.
//  Copyright © 2016 Daler Asrorov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CollectionViewCell.h"

@interface CollectionPlacesViewController : UICollectionViewController  <UICollectionViewDelegate, UITextViewDelegate, UITextFieldDelegate>


@end
